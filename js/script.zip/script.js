let cookiesAgreement = document.querySelector('.cookies-agreement');
let cookiesButton = document.querySelector('.cookies-button');
let mainMenu = document.querySelector('.main-menu');
let menuButton = document.querySelector('.menu-button');
cookiesButton.onclick = function() {
    cookiesAgreement.classList.add('cookies-agreement-closed');
};
menuButton.classList.add('menu-open');
menuButton.onclick = function() {
    // Перемикання класів для меню
    mainMenu.classList.toggle('menu-close');
    menuButton.classList.toggle('menu-open');
};
