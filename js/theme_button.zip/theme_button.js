let themeContainer = document.querySelector(".page");
let theme_button = document.querySelector(".theme-button");
 theme_button.onclick = function() {
    themeContainer.classList.toggle("dark-theme");
};